package com.rahman.line;

import java.io.Serializable;

public class Hospital{

	public String name;
	public String cat;

	public String disc;
	
	public String phone;

	public String website;
	public String address;
	
	
}
